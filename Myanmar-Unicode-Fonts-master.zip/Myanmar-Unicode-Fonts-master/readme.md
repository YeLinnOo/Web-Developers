# Myanmar Unicode Fonts

> Myanmar Unicode Fonts

## Download

[ Download ][download]

## Myanmar Unicode Fonts

- [ CherryUnicode ](./CherryUnicode)
- [ Gantgaw ](./Gantgaw)
- [ JasmineUnicode ](./JasmineUnicode)
- [ KT_Unicode ](./KT_Unicode)
- [ MON3_Anonta ](./MON3_Anonta)
- [ MasterpieceUniRound ](./MasterpieceUniRound)
- [ Myanmar3 ](./Myanmar3)
- [ Myanmar3_PaOh ](./Myanmar3_PaOh)
- [ MyanmarAngoun ](./MyanmarAngoun)
- [ MyanmarBlack ](./MyanmarBlack)
- [ MyanmarCensus ](./MyanmarCensus)
- [ MyanmarGantGaw ](./MyanmarGantGaw)
- [ MyanmarKhway ](./MyanmarKhway)
- [ MyanmarKuttar ](./MyanmarKuttar)
- [ MyanmarNayone ](./MyanmarKuttar)
- [ MyanmarNjaun ](./MyanmarNjaun)
- [ MyanmarPaOhOne ](./MyanmarPaOhOne)
- [ MyanmarPaOhRosemary ](./MyanmarPaOhRosemary)
- [ MyanmarPauklay ](./MyanmarPauklay)
- [ MyanmarPhetsot ](./MyanmarPhetsot)
- [ MyanmarPixel ](./MyanmarPixel)
- [ MyanmarPonenyet ](./MyanmarPonenyet)
- [ MyanmarPunk ](./MyanmarPunk)
- [ MyanmarRosemarry ](./MyanmarRosemarry)
- [ MyanmarSabae ](./MyanmarSabae)
- [ MyanmarSagar ](./MyanmarSagar)
- [ MyanmarSansPro ](./MyanmarSansPro)
- [ MyanmarSquare ](./MyanmarSquare)
- [ MyanmarTagu ](./MyanmarTagu)
- [ MyanmarTaungyi ](./MyanmarTaungyi)
- [ MyanmarText ](./MyanmarText)
- [ MyanmarTextMelano ](./MyanmarTextMelano)
- [ MyanmarThuriya ](./MyanmarThuriya)
- [ MyanmarYinmar ](./MyanmarYinmar)
- [ Namkhon ](./Namkhon)
- [ NotoSansMyanmar ](./NotoSansMyanmar)
- [ Padauk ](./Padauk)
- [ PadaukKyaungchikote ](./PadaukKyaungchikote)
- [ PadaukGhost ](./PadaukGhost)
- [ PadaukGrandPro ](./PadaukGrandPro)
- [ PadaukSagar ](./PadaukSagar)
- [ PadaukSgaw ](./PadaukSgaw)
- [ PangLong ](./PangLong)
- [ PaohDragonApp ](./PaohDragonApp)
- [ Parabaik ](./Parabaik)
- [ Pyidaungsu ](./Pyidaungsu)
- [ SamsungMyanmar ](./SamsungMyanmar)
- [ ShanUnicode ](./ShanUnicode)
- [ Thanlwin ](./Thanlwin)
- [ Tharlon ](./Tharlon)
- [ WinUniInnwa ](./WinUniInnwa)
- [ YoeYarOne ](./YoeYarOne)
- [ Yunghkio ](./Yunghkio)

### Credit

[1](https://app.box.com/s/303d59rj7rbqmmewcy1szssojywd6sfa)
[2](https://www.mediafire.com/folder/3amsfgkvkw7dh)
[3](https://my.pcloud.com/publink/show?code=xdt#folder=14258538)
[4](https://github.com/khmertype)
[5](https://www.mediafire.com/folder/3amsfgkvkw7dh)
[6](https://app.box.com/s/718wwwoatzr1gy531o4bgqqg4g2hh8m9)

### Myanmar Unicode Area

- [Myanmar Unicode Area](https://www.facebook.com/groups/mmUnicode/)
- [Myanmar Unicode လမ်းညွှန်](http://mmunicode.org/)

[download]: https://github.com/AungMyoKyaw/Myanmar-Unicode-Fonts/releases/latest
